P1Charts
========

Projeto da disciplina de programação 1 de 2013.2

Instalar os seguintes arquivos:
* CMake
* git
* Biblioteca cairo
* Biblioteca Jansson
 
Dica do malandro
----------------

Usem linux!
